package com.example.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView displayTextView;
    private TextView historyTextView;
    private String currentInput = "";
    private String currentOperation = "";
    private double firstOperand = 0;
    private boolean isNewOperation = true;
    private List<String> historyList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayTextView = findViewById(R.id.displayTextView);
        historyTextView = findViewById(R.id.historyTextView);

        // Number buttons
        int[] numberButtonIds = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        };

        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(v -> onNumberButtonClick(((Button) v).getText().toString()));
        }

        // Operation buttons
        findViewById(R.id.btnAdd).setOnClickListener(v -> onOperationButtonClick("+"));
        findViewById(R.id.btnSubtract).setOnClickListener(v -> onOperationButtonClick("-"));
        findViewById(R.id.btnMultiply).setOnClickListener(v -> onOperationButtonClick("×"));
        findViewById(R.id.btnDivide).setOnClickListener(v -> onOperationButtonClick("÷"));

        // Other buttons
        findViewById(R.id.btnDecimal).setOnClickListener(v -> onDecimalButtonClick());
        findViewById(R.id.btnClear).setOnClickListener(v -> clearAll());
        findViewById(R.id.btnDelete).setOnClickListener(v -> deleteLastChar());
        findViewById(R.id.btnEquals).setOnClickListener(v -> calculateResult());
    }

    private void onNumberButtonClick(String number) {
        if (isNewOperation) {
            currentInput = number;
            isNewOperation = false;
        } else {
            currentInput += number;
        }
        updateDisplay();
    }

    private void onDecimalButtonClick() {
        if (isNewOperation) {
            currentInput = "0.";
            isNewOperation = false;
        } else if (!currentInput.contains(".")) {
            currentInput += ".";
        }
        updateDisplay();
    }

    private void onOperationButtonClick(String operation) {
        if (!currentInput.isEmpty()) {
            if (!currentOperation.isEmpty()) {
                calculateResult();
            }
            firstOperand = Double.parseDouble(currentInput);
            currentOperation = operation;
            currentInput = "";
            updateHistory();
        } else if (!currentOperation.isEmpty()) {
            // Allow changing the operation if no new number was entered
            currentOperation = operation;
            updateHistory();
        }
    }

    private void calculateResult() {
        if (!currentOperation.isEmpty() && !currentInput.isEmpty()) {
            double secondOperand = Double.parseDouble(currentInput);
            double result = 0;

            switch (currentOperation) {
                case "+":
                    result = firstOperand + secondOperand;
                    break;
                case "-":
                    result = firstOperand - secondOperand;
                    break;
                case "×":
                    result = firstOperand * secondOperand;
                    break;
                case "÷":
                    if (secondOperand != 0) {
                        result = firstOperand / secondOperand;
                    } else {
                        currentInput = "Error";
                        updateDisplay();
                        return;
                    }
                    break;
            }

            // Add to history
            String historyEntry = firstOperand + " " + currentOperation + " " + secondOperand + " = " + result;
            historyList.add(historyEntry);
            updateHistoryDisplay();

            currentInput = String.valueOf(result);
            currentOperation = "";
            isNewOperation = true;
            updateDisplay();
        }
    }

    private void clearAll() {
        currentInput = "";
        currentOperation = "";
        firstOperand = 0;
        isNewOperation = true;
        updateDisplay();
        historyTextView.setText("");
    }

    private void deleteLastChar() {
        if (!currentInput.isEmpty()) {
            currentInput = currentInput.substring(0, currentInput.length() - 1);
            if (currentInput.isEmpty()) {
                currentInput = "0";
                isNewOperation = true;
            }
            updateDisplay();
        }
    }

    private void updateDisplay() {
        if (currentInput.isEmpty()) {
            displayTextView.setText("0");
        } else {
            // Remove trailing .0 if it's an integer
            if (currentInput.endsWith(".0")) {
                displayTextView.setText(currentInput.substring(0, currentInput.length() - 2));
            } else {
                displayTextView.setText(currentInput);
            }
        }
    }

    private void updateHistory() {
        String historyText = firstOperand + " " + currentOperation;
        historyTextView.setText(historyText);
    }

    private void updateHistoryDisplay() {
        StringBuilder historyBuilder = new StringBuilder();
        for (String entry : historyList) {
            historyBuilder.append(entry).append("\n");
        }
        historyTextView.setText(historyBuilder.toString());
    }
}